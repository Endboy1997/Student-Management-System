
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class StudentManagementGUI extends JFrame {
    private JTextField idField, nameField, courseField;
    private JTextArea outputArea;
    private ArrayList<Student> students = new ArrayList<>();

    public StudentManagementGUI() {
        setTitle("Student Management System");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel idLabel = new JLabel("ID:");
        idLabel.setBounds(20, 20, 80, 25);
        add(idLabel);
        idField = new JTextField();
        idField.setBounds(100, 20, 165, 25);
        add(idField);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(20, 50, 80, 25);
        add(nameLabel);
        nameField = new JTextField();
        nameField.setBounds(100, 50, 165, 25);
        add(nameField);

        JLabel courseLabel = new JLabel("Course:");
        courseLabel.setBounds(20, 80, 80, 25);
        add(courseLabel);
        courseField = new JTextField();
        courseField.setBounds(100, 80, 165, 25);
        add(courseField);

        JButton addButton = new JButton("Add Student");
        addButton.setBounds(100, 120, 165, 25);
        add(addButton);

        outputArea = new JTextArea();
        outputArea.setBounds(20, 160, 340, 180);
        add(outputArea);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                String course = courseField.getText();
                students.add(new Student(id, name, course));
                updateOutput();
                clearFields();
            }
        });
    }

    private void updateOutput() {
        outputArea.setText("");
        for (Student s : students) {
            outputArea.append(s + "\n");
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        courseField.setText("");
    }

    public static void main(String[] args) {
        new StudentManagementGUI().setVisible(true);
    }
}
